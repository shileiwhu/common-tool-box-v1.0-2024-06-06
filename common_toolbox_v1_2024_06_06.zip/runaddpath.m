function [] = runaddpath()

% root % path for Windows
toolboxroot = [pwd '/toolbox'];

% all dir
dr = dir(toolboxroot);
for kk=1:length(dr)
if ~strcmp(dr(kk).name,'.')&~strcmp(dr(kk).name,'..')
    disp(fullfile(toolboxroot,dr(kk).name));
    addpath(fullfile(toolboxroot,dr(kk).name));
end
end

end
